$.ajax({
  url:'https://randomuser.me/api/? results=12&nat=name,picture,email,location,cell,dob'
  dataType: 'json',
  success: function(data) {
    console.log(data);
  }
});
{
  `let employees;

$.ajax({ url: 'https://randomuser.me/api/?results=12&nat=name,picture,email,location,cell,dob', dataType: 'json', success: function(data) { employees = data.results; console.log(employees); } });`
 